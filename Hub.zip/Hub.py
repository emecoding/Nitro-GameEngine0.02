#!/usr/bin/env python3


from PyQt5 import QtWidgets
import sys
import sqlite3


class Hub(QtWidgets.QMainWindow):
    def __init__(self):
        super(Hub, self).__init__()
        self.dir = None
        self.standart_files_dir = "standart_files/"
        self.set_Hub_ready()
        self.setWindowTitle("Nitro Hub 0.02")
        self.setGeometry(100, 100, 800, 800)

    def set_Hub_ready(self):
        #print("P")
        create_new_project_btn = QtWidgets.QPushButton(self)
        create_new_project_btn.setText("Create new Project")
        create_new_project_btn.clicked.connect(self.create_new_project)
        create_new_project_btn.move(350, 0)
        self.update_QWidget(create_new_project_btn)

    def update_QWidget(self, w):
        w.setVisible(True)
        w.setEnabled(True)
        w.adjustSize()




    def create_new_project(self):
        name_entry = QtWidgets.QLineEdit(self)
        name_entry.move(350, 100)
        name_entry.setText("New Project")

        choose_dir_btn = QtWidgets.QPushButton(self)
        choose_dir_btn.setText("Choose Dir")
        choose_dir_btn.move(350, 125)
        choose_dir_btn.clicked.connect(self.set_new_projects_dir)

        apply_btn = QtWidgets.QPushButton(self)
        apply_btn.setText("Create")
        apply_btn.move(350, 150)
        apply_btn.clicked.connect(lambda: self.apply_new_project(name_entry.text()))

        self.update_QWidget(name_entry)
        self.update_QWidget(choose_dir_btn)
        self.update_QWidget(apply_btn)


    def set_new_projects_dir(self):
        project_dir = QtWidgets.QFileDialog.getExistingDirectory(self, "Select folder to save in!")
        self.dir = project_dir

    def read_file(self, file_name):
        s = ""
        with open(file_name, "r") as file:
            s = file.read()
            file.close()

        return s

    def apply_new_project(self, name_string):
        name_string = name_string.replace(" ", "_")
        print(self.dir)

        project_file_index = f'''
from NitroEditor import NitroEditor as e
from PyQt5 import QtWidgets
import sys
import sqlite3
        
class project:
    def __init__(self, {name_string}):
    
        self.name = {name_string}
        
        self.editor = e(self.name, '{self.dir}')
        self.editor.show()

app = QtWidgets.QApplication(sys.argv)                
p = project('{name_string}')
app.exec_()                
        
'''


        standart_editor_file_dir = self.standart_files_dir + "NitroEditor.py"
        editor_file_index = self.read_file(standart_editor_file_dir)

        standart_gameObject_file_dir = self.standart_files_dir + "GameObject.py"
        gameObject_file_index = self.read_file(standart_gameObject_file_dir)

        standart_saver_file_dir = self.standart_files_dir + "saver.py"
        saver_file_index = self.read_file(standart_saver_file_dir)

        standart_components_file_dir = self.standart_files_dir + "components.py"
        components_file_index = self.read_file(standart_components_file_dir)

        standart_behaviour_file_dir = self.standart_files_dir + "GameObjects_behaviours.py"
        behaviour_file_index = self.read_file(standart_behaviour_file_dir)

        standart_loader_file_dir = self.standart_files_dir + "loader.py"
        loader_file_index = self.read_file(standart_loader_file_dir)

        standart_mouse_file_dir = self.standart_files_dir + "Mouse.py"
        Mouse_file_index = self.read_file(standart_mouse_file_dir)

        standart_compiler_file_dir = self.standart_files_dir + "Compiler.py"
        compiler_file_index = self.read_file(standart_compiler_file_dir)

        standart_sound_engine_file_dir = self.standart_files_dir + "Sound_Engine.py"
        sound_engine_file_index = self.read_file(standart_sound_engine_file_dir)

        with open(self.dir + "/Project.py", "w+") as f:
            f.write(project_file_index)
            f.close()

        with open(self.dir + "/NitroEditor.py", "w+") as f:
            f.write(editor_file_index)
            f.close()

        with open(self.dir + "/GameObject.py", "w+") as f:
            f.write(gameObject_file_index)
            f.close()

        with open(self.dir + "/saver.py", "w+") as f:
            f.write(saver_file_index)
            f.close()

        with open(self.dir + "/components.py", "w+") as f:
            f.write(components_file_index)
            f.close()

        with open(self.dir + "/GameObjects_behaviours.py", "w+") as f:
            f.write(behaviour_file_index)
            f.close()

        with open(self.dir + "/loader.py", "w+") as f:
            f.write(loader_file_index)
            f.close()

        with open(self.dir + "/Mouse.py", "w+") as f:
            f.write(Mouse_file_index)
            f.close()

        with open(self.dir + "/Compiler.py", "w+") as f:
            f.write(compiler_file_index)
            f.close()

        with open(self.dir + "/Sound_Engine.py", "w+") as f:
            f.write(sound_engine_file_index)
            f.close()


        self.close()



        #print(name_string)





app = QtWidgets.QApplication(sys.argv)
h = Hub()
h.show()
app.exec_()