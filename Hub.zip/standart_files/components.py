import pygame

class RigidBody():
    def __init__(self, GameObject, c):
        self.GameObject = GameObject
        self.gravity = 5
        self.mass = 4
        self.name = "RigidBody"
        self.moving_down = True
        self.can_add_only_once = True
        self.bx = c


    def work(self):
        if self.bx != None:
            if self.bx.is_collided_bottom == False:
                self.moving_down = True
            else:
                self.moving_down = False
                if self.bx.collider != None:
                    c = self.GameObject.editor.Build_In_Functions.Find_GameObject_With_Tag(self.bx.collider.tag)
                    p = self.gravity - self.mass
                    self.Add_Force(c, -2, p) #1 = RIGHT, -1 = LEFT, 2 = UP, -2 = DOWN
            if self.bx.is_collided_right == True:
                if self.bx.collider != None:
                    c = self.GameObject.editor.Build_In_Functions.Find_GameObject_With_Tag(self.bx.collider.tag)
                    p = self.gravity - self.mass
                    self.Add_Force(c, 1, p)
            if self.bx.is_collided_left == True:
                if self.bx.collider != None:
                    c = self.GameObject.editor.Build_In_Functions.Find_GameObject_With_Tag(self.bx.collider.tag)
                    p = self.gravity - self.mass
                    self.Add_Force(c, -1, p)
            if self.bx.is_collided_top == True:
                if self.bx.collider != None:
                    c = self.GameObject.editor.Build_In_Functions.Find_GameObject_With_Tag(self.bx.collider.tag)
                    p = self.gravity - self.mass
                    self.Add_Force(c, 2, p)
        else:
            self.moving_down = True





        if self.moving_down == True:
            self.GameObject.pos_y += self.gravity


    def Add_Force(self, GameObject, way, power):
        if way == -2:
            GameObject.pos_y += power
        elif way == 2:
            GameObject.pos_y -= power
        elif way == 1:
            GameObject.pos_x += power
        elif way == -1:
            GameObject.pos_x -= power







class BoxCollider():
    def __init__(self, GameObject, lst):
        self.GameObject = GameObject
        self.name = "BoxCollider"
        self.lst = lst
        self.GameObject.has_colliders = True
        self.collider = None
        self.is_collided_left = False
        self.is_collided_right = False
        self.is_collided_top = False
        self.is_collided_bottom = False
        self.can_add_only_once = True

    def work(self):
        for obj in self.lst:
            if obj != self.GameObject:
                if obj.has_colliders == True:
                    if self.GameObject.Rect.colliderect(obj.Rect):
                        #print("Collided with " + obj.name)
                        self.collider = obj
                        if self.GameObject.Rect.right >= obj.Rect.left:
                            if self.GameObject.Rect.right <= obj.Rect.right:
                                self.is_collided_right = True
                            else:
                                self.is_collided_right = False
                        else:
                            self.is_collided_right = False

                        if self.GameObject.Rect.left <= obj.Rect.right:
                            if self.GameObject.Rect.left >= obj.Rect.left:
                                self.is_collided_left = True
                            else:
                                self.is_collided_left = False
                        else:
                            self.is_collided_left = False

                        if self.GameObject.Rect.bottom >= obj.Rect.top:
                            if self.GameObject.Rect.bottom <= obj.Rect.bottom:
                                self.is_collided_bottom = True
                            else:
                                self.is_collided_bottom = False
                        else:
                            self.is_collided_bottom = False

                        if self.GameObject.Rect.top <= obj.Rect.bottom:
                            if self.GameObject.Rect.top >= obj.Rect.top:
                                self.is_collided_top = True
                            else:
                                self.is_collided_top = False
                        else:
                            self.is_collided_top = False
                        #print(str(self.is_collided_left) + ", " + self.name)
                        #print(str(self.is_collided_right) + ", " + self.name)
                else:
                    self.is_collided_left = False
                    self.is_collided_top = False
                    self.is_collided_bottom = False
                    self.is_collided_right = False
            else:
                self.is_collided_left = False
                self.is_collided_top = False
                self.is_collided_bottom = False
                self.is_collided_right = False


        #print(self.collider)

        if self.is_collided_bottom == False and self.is_collided_left == False and self.is_collided_right == False and self.is_collided_top == False:
            self.collider = None

            #print(str(self.is_collided_left) + ", " + self.name)
            #print(str(self.is_collided_right) + ", " + self.name)


class Animator():
    def __init__(self, GameObject, pics_lst):
        self.GameObject = GameObject
        self.imgs_lst = pics_lst
        self.is_playing = False
        self.current_img = 0
        self.frame_duration = 7
        self.set_frames(self.frame_duration)

    def set_frames(self, frames):
        for img in self.imgs_lst:
            for frame in range(frames):
                copy = img.copy()
                self.imgs_lst.append(copy)


    def play(self):
        if self.current_img + 1 >= (len(self.imgs_lst) - 1):
            self.current_img = 0

        self.GameObject.img = self.imgs_lst[self.current_img]
        self.current_img += 1














