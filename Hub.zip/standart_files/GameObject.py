from PyQt5 import QtWidgets
from components import *
from GameObjects_behaviours import Behavior
import pygame

class GameObject:
    def __init__(self, name, pos_x, pos_y, screen, editor):
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y



        self.children_lst = []
        self.parent = None


        self.id = 0

        self.scene_pos_x = self.pos_x
        self.scene_pos_y = self.pos_y

        self.tag = "None"

        self.editor = editor

        self.scale_x = 32
        self.scale_y = 32

        self.available_components_lst = []
        self.all_components_lst = []


        self.screen = screen
        self.has_colliders = False

        self.Behaviour = Behavior(self)


        self.img_dir = ""
        self.img = None

        self.Rect = pygame.Rect(self.pos_x, self.pos_y, self.scale_x, self.scale_y)

    def take_child(self, child):
        self.children_lst.append(child)

    def make_child(self, parent):
        self.parent = parent


    def open_in_inspector(self, inspector_label, btn_to_update):
        inspector_label.close()
        inspector_label = QtWidgets.QLabel(self.editor)
        inspector_label.setGeometry(600, 0, 200, 600)
        self.update_QWidget(inspector_label)

        name_entry = QtWidgets.QLineEdit(inspector_label)
        name_entry.setText(self.name)
        name_entry.setGeometry(50, 0, 150, 25)
        name_label = QtWidgets.QLabel(inspector_label)
        name_label.setText("Name: ")
        name_label.setGeometry(0, 0, 50, 25)
        self.update_QWidget(name_label)

        self.update_QWidget(name_entry)
        tag_entry = QtWidgets.QLineEdit(inspector_label)
        tag_entry.setText(str(self.tag))
        tag_entry.setGeometry(50, 25 ,150, 25)
        self.update_QWidget(tag_entry)
        tag_label = QtWidgets.QLabel(inspector_label)
        tag_label.setText("Tag: ")
        tag_label.setGeometry(0, 25, 50, 25)
        self.update_QWidget(tag_label)

        pos_x_entry = QtWidgets.QLineEdit(inspector_label)
        pos_x_entry.setText(str(self.pos_x))
        pos_x_entry.setGeometry(50, 50, 150, 25)
        self.update_QWidget(pos_x_entry)
        pos_x_label = QtWidgets.QLabel(inspector_label)
        pos_x_label.setText("Pos X: ")
        pos_x_label.setGeometry(0, 50, 50, 25)
        self.update_QWidget(pos_x_label)


        pos_y_entry = QtWidgets.QLineEdit(inspector_label)
        pos_y_entry.setText(str(self.pos_y))
        pos_y_entry.setGeometry(50, 75, 150, 25)
        self.update_QWidget(pos_y_entry)
        pos_y_label = QtWidgets.QLabel(inspector_label)
        pos_y_label.setText("Pos Y: ")
        pos_y_label.setGeometry(0, 75, 50, 25)
        self.update_QWidget(pos_y_label)

        scale_x_entry = QtWidgets.QLineEdit(inspector_label)
        scale_x_entry.setText(str(self.scale_x))
        scale_x_entry.setGeometry(50, 100, 150, 25)
        scale_x_label = QtWidgets.QLabel(inspector_label)
        scale_x_label.setText("Scale X: ")
        scale_x_label.setGeometry(0, 100, 50, 25)
        self.update_QWidget(scale_x_label)
        self.update_QWidget(scale_x_entry)

        scale_y_entry = QtWidgets.QLineEdit(inspector_label)
        scale_y_entry.setText(str(self.scale_y))
        scale_y_entry.setGeometry(50, 125, 150, 25)
        scale_y_label = QtWidgets.QLabel(inspector_label)
        scale_y_label.setText("Scale Y: ")
        scale_y_label.setGeometry(0, 125, 50, 25)
        self.update_QWidget(scale_y_label)
        self.update_QWidget(scale_y_entry)

        set_img_btn = QtWidgets.QPushButton(inspector_label)
        set_img_btn.setGeometry(50, 150, 150, 25)
        set_img_btn.setText("Set Image")
        set_img_btn.clicked.connect(self.set_new_image)
        self.update_QWidget(set_img_btn)
        apply_btn = QtWidgets.QPushButton(inspector_label)
        apply_btn.setText("Apply")
        apply_btn.clicked.connect(lambda: self.apply_new_settings(name_entry.text(), pos_x_entry.text(), pos_y_entry.text(),scale_x_entry.text(),scale_y_entry.text() ,tag_entry.text(), inspector_label, btn_to_update))
        apply_btn.setGeometry(50, 175, 150, 25)
        self.update_QWidget(apply_btn)


        '''if self.parent != None:
            current_parent_label = QtWidgets.QLabel(inspector_label)
            current_parent_label.setGeometry(50, 200, 150, 25)
            current_parent_label.setText("Parent: " + str(self.parent.name))
            self.update_QWidget(current_parent_label)
        else:
            current_parent_label = QtWidgets.QLabel(inspector_label)
            current_parent_label.setGeometry(50, 200, 150, 25)
            current_parent_label.setText("Parent: None")
            self.update_QWidget(current_parent_label)


        make_child_of_gameObject_btn = QtWidgets.QPushButton(inspector_label)
        make_child_of_gameObject_btn.setText("Make Child Of")
        make_child_of_gameObject_btn.clicked.connect(lambda: self.select_new_parent(inspector_label))
        make_child_of_gameObject_btn.setGeometry(50, 225, 150, 25)
        self.update_QWidget(make_child_of_gameObject_btn)

    def select_new_parent(self, l):
        available_parents_widget = QtWidgets.QListWidget(l)
        available_parents_widget.setGeometry(50, 275, 150, 50)

        available_parents_lst = []
        for obj in self.editor.all_gameObjects_lst:
            if obj != self:
                if obj != self.parent:
                    available_parents_lst.append(obj)

        i = 0
        for parent in available_parents_lst:
            available_parents_widget.insertItem(i, parent.name)
            i += 1

        self.update_QWidget(available_parents_widget)

        apply_btn = QtWidgets.QPushButton(l)
        apply_btn.setGeometry(50, 300, 150, 25)
        apply_btn.setText("Apply new parent")
        apply_btn.clicked.connect(lambda: self.apply_new_parent(available_parents_widget, apply_btn))
        self.update_QWidget(apply_btn)

    def apply_new_parent(self, widget, b):
        new_parent = widget.currentItem()

        available_parents_lst = []
        for obj in self.editor.all_gameObjects_lst:
            if obj != self:
                if obj != self.parent:
                    available_parents_lst.append(obj)


        can_add = False
        for parent in available_parents_lst:
            if parent.name == new_parent.text():
                if self in parent.children_lst:
                    can_add = False
                else:
                    can_add = True

                if can_add:
                    parent.children_lst.append(self)
                    self.parent = parent
                else:
                    print("Couldn't add")




                #print(self.parent)
                #print(parent.children_lst)

        widget.close()
        b.close()'''



        """ew_component_btn = QtWidgets.QPushButton(inspector_label)
        new_component_btn.setText("Add Component")
        new_component_btn.clicked.connect(lambda: self.append_components_lst(inspector_label))
        new_component_btn.setGeometry(50, 150, 150, 25)
        self.update_QWidget(new_component_btn)"""


    '''def append_components_lst(self, inspector_label):

        available_components_widget = QtWidgets.QListWidget(inspector_label)
        available_components_widget.setGeometry(0, 400, 100, 200)
        available_components_widget.clicked.connect(lambda: self.apply_new_component(available_components_widget))

        i = 0
        for a_component in self.available_components_lst:
            available_components_widget.insertItem(i, a_component.name)
            i += 1

        self.update_QWidget(available_components_widget)

    def apply_new_component(self, widget):
        item = widget.currentItem()
        for component in self.available_components_lst:
            if component.name == item.text():
                self.all_components_lst.append(component)
                if component.can_add_only_once:
                    self.available_components_lst.remove(component)
                    widget.close()'''

    def return_to_scene_pos(self):
        self.pos_x = self.scene_pos_x
        self.pos_y = self.scene_pos_y

    def my_behaviour(self):
        self.Behaviour.behave()
    def draw(self):
        self.screen.blit(self.img, (self.pos_x, self.pos_y))

    def components_work(self):
        self.Rect = pygame.Rect(self.pos_x, self.pos_y, self.scale_x, self.scale_y)
        self.my_behaviour()


    def set_new_image(self):
        file_name, filter = QtWidgets.QFileDialog.getOpenFileName(None, "Open Image", "/",  "Image Files (*.png *.jpg*)")
        file_dir = file_name
        self.img_dir = file_dir
        #print(str(self.img_dir))
        img = pygame.image.load(str(self.img_dir))
        self.img = img
        self.img = pygame.transform.scale(self.img, (self.scale_x, self.scale_y))
        self.screen.blit(self.img, (self.pos_x, self.pos_y))
        pygame.display.update()


    def apply_new_settings(self, n, p_x, p_y,s_x, s_y,tag,inspector_label, btn_to_update):
        self.name = n
        self.tag = tag

        if p_x != "" or p_x != " ":
            self.pos_x = int(p_x)
            self.scene_pos_x = int(p_x)

        if p_y != "" or p_y != " ":
            self.pos_y = int(p_y)
            self.scene_pos_y = int(p_y)

        if s_x != "" or s_x != " ":
            self.scale_x = int(s_x)

        if s_y != "" or s_y != " ":
            self.scale_y = int(s_y)

        btn_to_update.setText(self.name)
        self.update_QWidget(btn_to_update)
        self.screen.fill((0, 0, 0))
        if self.img != None:
            self.img = pygame.transform.scale(self.img, (self.scale_x, self.scale_y))
            self.draw()
        for obj in self.editor.all_gameObjects_lst:
            if obj.img != None:
                obj.draw()

        pygame.display.update()


        inspector_label.clear()




    def update_QWidget(self, w):
        w.setVisible(True)
        w.setEnabled(True)
        #w.adjustSize()