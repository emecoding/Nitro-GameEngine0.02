import pygame

pygame.init()

class Sound_Engine():
    def __init__(self, editor):
        self.editor = editor

    def play_background_music(self, source):
        pygame.mixer.music.load(source)
        pygame.mixer.music.play(-1)

    def play_sound(self, source):
        pygame.mixer.music.load(source)
        pygame.mixer.music.play(0)