from PyQt5 import QtWidgets
from PyQt5.Qt import Qt
from PyQt5.QtGui import *
from GameObject import GameObject
from loader import loader
from saver import saver
from Compiler import Compiler
from Sound_Engine import Sound_Engine
from Mouse import Mouse
import sys
import sqlite3
import pygame
import os

class NitroEditor(QtWidgets.QMainWindow):
    def __init__(self, project_name, dir):
        super(NitroEditor, self).__init__()


        self.clock = pygame.time.Clock()

        self.Sound_Engine = Sound_Engine(self)

        self.Build_In_Functions = Build_In_Fuctions(self)
        self.all_gameObjects_lst = []

        self.project_name = project_name

        self.current_btn_y = 0

        self.compiler = Compiler(self)
        self.is_compiled = False

        self.dir = dir
        #print(self.dir)
        self.saver = saver(self)
        self.database_file_dir = self.saver.create_new_objs_table_if_not_found()
        self.saver.create_new_project_state_table_if_not_found()

        #self.Mouse = Mouse(self)

        self.loader = loader(self.database_file_dir, self)
        self.set_window_and_label_ready()

        is_old_project = self.loader.is_old_project()
        #print(is_old_project)

        if is_old_project:
            #print("It's old Project")
            self.loader.load()
            #self.read_if_compiled()
        else:
            #print("It's new project")
            self.loader.make_old_project()

        self.is_playing = False



        self.Console = Console(self)

        self.read_if_compiled()



    def read_if_compiled(self):
        self.build_dir = ""

        try:
            conn = sqlite3.connect(self.database_file_dir)
            cursor = conn.cursor()
            q = "SELECT * FROM project_state"
            cursor.execute(q)
            s = cursor.fetchall()
            #print(s)
            self.build_dir = s[1][2]
            #print(self.build_dir)


            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            print("Error came out!, ", e)
        try:
            #print(type(self.build_dir))
            #print(self.build_dir)
            if self.build_dir != None:
                #print(self.build_dir)
                conn = sqlite3.connect(self.build_dir + "/" + self.project_name + ".db")
                cursor = conn.cursor()
                q = "SELECT * FROM project_state;"
                cursor.execute(q)
                conn.commit()
                lst = cursor.fetchall()
                #print(lst)
                conn.close()
                self.is_compiled = bool(lst[0][1])
                b_d = lst[0][2]

                current_dir = os.getcwd()
                if b_d == current_dir:
                    #print(self.is_compiled)
                    if self.is_compiled:
                        self.setVisible(False)
                        self.play()
        except sqlite3.Error as e:
            print("Error came out!  ", e)

        finally:
            self.is_compiled = False



    def set_window_and_label_ready(self):
        self.setWindowTitle(self.project_name)
        self.setGeometry(0, 0, 800, 800)
        self.scene_win = pygame.display.set_mode((800, 600))

        self.hierarchy_label = QtWidgets.QLabel(self)
        self.hierarchy_label.setGeometry(0, 0, 200, 600)
        #self.hierarchy_label.setStyleSheet("background-color:green")

        self.inspector_label = QtWidgets.QLabel(self)
        self.inspector_label.setGeometry(600, 0, 200, 600)

        #self.inspector_label.setStyleSheet("background-color:blue")

        self.action_label = QtWidgets.QLabel(self)
        self.action_label.setGeometry(0, 600, 800, 200)
        #self.action_label.setStyleSheet("background-color:pink")
        create_new_gameObject_btn = QtWidgets.QPushButton(self.action_label)
        create_new_gameObject_btn.setText("Create New GameObject")
        create_new_gameObject_btn.clicked.connect(self.on_create_new_gameObject_btn_clicked)
        self.update_QWidget(create_new_gameObject_btn)
        save_btn = QtWidgets.QPushButton(self.action_label)
        save_btn.setText("Save")
        save_btn.clicked.connect(lambda: self.saver.save(self.all_gameObjects_lst))
        save_btn.move(0, 25)
        self.update_QWidget(save_btn)

        play_btn = QtWidgets.QPushButton(self.action_label)
        play_btn.setText("Play")
        play_btn.clicked.connect(self.play)
        play_btn.move(0, 50)
        self.update_QWidget(play_btn)

        compile_btn = QtWidgets.QPushButton(self.action_label)
        compile_btn.setText("Compile")
        compile_btn.clicked.connect(self.compiler.compile)
        compile_btn.move(0, 75)
        self.update_QWidget(compile_btn)



        self.console_label = QtWidgets.QLabel(self)
        self.console_label.setGeometry(200, 0, 400, 600)
        #self.console_label.setStyleSheet("background-color:gray")




    def stop_playing(self):
        self.is_playing = False
        self.scene_win.fill((0, 0, 0))
        for obj in self.all_gameObjects_lst:
            #print(obj.name)
            obj.return_to_scene_pos()

        pygame.display.update()

        #print(self.is_compiled)
        if self.is_compiled:
            pygame.quit()
            sys.exit()

    def editor_input_while_playing(self):
        #print("Inputting")
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LCTRL:
                    #print("Pressed q")
                    if self.is_compiled == False:
                        self.stop_playing()
            if event.type == pygame.QUIT:
                #print("Quitted")
                if self.is_compiled == True:
                    self.stop_playing()

    def render_GameObjects(self):
        for x in self.all_gameObjects_lst:
            if x.img != None:
                x.draw()
    def start(self):
        for i in self.all_gameObjects_lst:
            i.Behaviour.start()

    def end(self):
        for i in self.all_gameObjects_lst:
            i.Behaviour.end()

    def play(self):
        self.FPS = 60
        self.start()
        self.is_playing = True
        current_obj = 0
        while self.is_playing:
            self.scene_win.fill((0, 0, 0))
            self.editor_input_while_playing()
            if len(self.all_gameObjects_lst) != 0:
                self.all_gameObjects_lst[current_obj].components_work()
                self.render_GameObjects()
                if ((current_obj + 1) <= (len(self.all_gameObjects_lst) - 1)):
                    current_obj += 1
                else:
                    current_obj = 0
            pygame.display.update()

            if len(self.all_gameObjects_lst) <= 1:
                self.FPS = 60
            else:
                self.FPS = 100


            self.clock.tick(self.FPS)

        self.end()


    def on_create_new_gameObject_btn_clicked(self):
        new_o = GameObject("New GameObject_" + str(len(self.all_gameObjects_lst)), 0, 0, self.scene_win, self)
        new_o.id = len(self.all_gameObjects_lst) + 1
        #print(new_o.id)
        self.all_gameObjects_lst.append(new_o)
        #print(self.all_gameObjects_lst)
        self.create_slot_for_new_gameObject(new_o)

    def create_slot_for_new_gameObject(self, obj):
        b = QtWidgets.QPushButton(self.hierarchy_label)
        b.setGeometry(0, self.current_btn_y, 50, 50)
        self.current_btn_y += 25
        b.setText(obj.name)
        b.clicked.connect(lambda: obj.open_in_inspector(self.inspector_label, b))
        self.update_QWidget(b)


    def update_QWidget(self, w):
        w.setVisible(True)
        w.setEnabled(True)
        w.adjustSize()




class Build_In_Fuctions():
    def __init__(self, editor):
        self.editor = editor

    def Find_GameObject_With_Tag(self, tag):
        Obj_to_return = None
        for obj in self.editor.all_gameObjects_lst:
            if obj.tag == tag:
                Obj_to_return = obj
                break

        return Obj_to_return

    def Find_GameObjects_With_Tag(self, tag):
        lst = []
        for obj in self.editor.all_gameObjects_lst:
            if obj.tag == tag:
                lst.append(obj)

        return lst


class Console():
    def __init__(self, editor):
        self.editor = editor
        self.y = 0


    def Log(self, what_to_log):
        b = QtWidgets.QPushButton(self.editor.console_label)
        b.setText(what_to_log)
        b.setGeometry(0, self.y, 400, 25)
        self.y += 25
        self.update_QWidget(b)

    def update_QWidget(self, w):
        w.setVisible(True)
        w.setEnabled(True)
