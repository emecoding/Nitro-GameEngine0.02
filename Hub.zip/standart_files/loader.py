import sqlite3
import pygame

from GameObject import GameObject

class loader():
    def __init__(self, file, e):
        self.file = file
        self.editor = e

    def make_compiled(self):
        try:
            self.conn = sqlite3.connect(self.file)
            self.cursor = self.conn.cursor()
            self.cursor.execute("INSERT INTO project_state(is_old_project, is_compiled)VALUES('True', 'True')")
            #print(self.cursor.fetchall())
            self.conn.close()
        except sqlite3.Error as e:
            print("Error came out! ", e)

    def is_old_project(self):
        is_old = False
        try:
            #print(self.file)
            self.conn = sqlite3.connect(self.file)
            self.cursor = self.conn.cursor()
            self.cursor.execute("SELECT * FROM project_state;")
            values = self.cursor.fetchall()
            #print(values)
            if values[0][0] == 'False':
                is_old = False
            else:
                is_old = True

            self.conn.close()
        except sqlite3.Error as e:
            print("Error came out! eee", e)

        return is_old

    def make_old_project(self):
        try:
            #print("Making old project")
            self.conn = sqlite3.connect(self.file)
            self.cursor = self.conn.cursor()
            self.cursor.execute("INSERT INTO project_state(is_old_project)VALUES('True')")
            self.conn.commit()
            #print(self.cursor.fetchall())
            self.conn.close()
            #print("Made to old project")
        except sqlite3.Error as e:
            print("Error came out! ", e)

    def load(self):
        #print("Loading")
        self.conn = sqlite3.connect(self.file)
        self.cursor = self.conn.cursor()

        self.cursor.execute("SELECT * FROM Objects")
        objs_lst = self.cursor.fetchall()
        # print(objs_lst)
        for obj in objs_lst:
            #print(obj[0],obj[1],obj[2],obj[3],obj[4],obj[5],obj[6],obj[7])
            name = obj[0]
            # print(name)
            pos_x = obj[1]
            pos_y = obj[2]
            img = obj[5]
            scale_x = obj[3]
            scale_y = obj[4]
            tag = obj[6]
            id = obj[7]
            #print(tag)
            new_o = GameObject(name, int(pos_x), int(pos_y), self.editor.scene_win, self.editor)
            self.editor.create_slot_for_new_gameObject(new_o)
            new_o.tag = tag
            #print(new_o.tag)
            new_o.id = int(id)

            new_o.scale_x = scale_x
            new_o.scale_y = scale_y

            if img != "None":
                #print(img)
                i = pygame.image.load(img)
                i = pygame.transform.scale(i, (new_o.scale_x, new_o.scale_y))
                new_o.img = i
                new_o.img_dir = img
                new_o.draw()
            else:
                new_o.img = None

            self.editor.all_gameObjects_lst.append(new_o)

        self.conn.close()
        pygame.display.update()
        self.editor.read_if_compiled()
