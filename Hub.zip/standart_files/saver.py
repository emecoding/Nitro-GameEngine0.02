import sqlite3
import os

class saver():
    def __init__(self, editor):
        self.editor = editor
        self.folder_dir = self.editor.dir
        self.database_file_dir = self.folder_dir + "/" + self.editor.project_name + ".db"
        self.table_name = "Objects"
        #self.create_new_objs_table_if_not_found()
        #self.create_new_project_state_table_if_not_found()




    def create_new_project_state_table_if_not_found(self):
        try:
            self.conn = sqlite3.connect(self.database_file_dir)
            self.cursor = self.conn.cursor()
            self.cursor.execute('CREATE TABLE IF NOT EXISTS project_state(is_old_project BOOLEAN, is_compiled BOOLEAN, build_dir text);')
            self.conn.commit()
            self.cursor.execute("INSERT INTO project_state(is_old_project, is_compiled)VALUES('False', 'False')")
            self.conn.commit()
            self.conn.close()
        except sqlite3.Error as e:
            print("Error came out! ", e)

    def create_new_objs_table_if_not_found(self):
        try:
            #os.mkdir(self.database_file_dir)
            self.conn = sqlite3.connect(self.database_file_dir)
            self.cursor = self.conn.cursor()
            #print(self.table_name)
            self.cursor.execute('CREATE TABLE IF NOT EXISTS ' + self.table_name + '(name text, pos_x INTEGER, pos_y INTEGER,scale_x INTEGER,scale_y INTEGER ,img_source text, tag text, id INTEGER);')
            self.conn.commit()
            self.conn.close()
        except sqlite3.Error as e:
            print("Error came out! ", e)

        return self.database_file_dir

    def save(self, lst):
        self.conn = sqlite3.connect(self.database_file_dir)
        self.cursor = self.conn.cursor()

        q1 = "UPDATE project_state SET is_old_project = 'True' WHERE is_old_project = 'False'"
        self.cursor.execute(q1)
        self.conn.commit()

        for obj in lst:
            is_old_obj = False

            self.cursor.execute("SELECT * FROM Objects")
            all_old_Objects_lst = self.cursor.fetchall()
            for old_Object in all_old_Objects_lst:
                #print(old_Object[0])
                if obj.id == old_Object[7]:
                    is_old_obj = True
                    if obj.img == None:
                        query = "UPDATE '" + "Objects" + "'" + " SET name = '" + str(obj.name) + "', pos_x = " + str(obj.pos_x) + ", pos_y = " + str(obj.pos_y) + ", scale_x = " + str(obj.scale_x) + ", scale_y = " + str(obj.scale_y) + ", img_source = 'None', tag = '" + str(obj.tag) + "' WHERE id = '" + str(old_Object[7]) + "'"
                        #print(query)
                        self.cursor.execute(query)
                        self.conn.commit()
                    else:
                        #print(str(obj.img_dir))
                        query = "UPDATE '" + "Objects" + "' " + "SET name = '" + str(
                            obj.name) + "', pos_x = " + str(obj.pos_x) + ", pos_y = " + str(
                            obj.pos_y) + ", scale_x = " + str(obj.scale_x) + ", scale_y = " + str(
                            obj.scale_y) + ", img_source = '" + str(obj.img_dir) + "', tag = '" + str(obj.tag) + "' WHERE id = " + str(old_Object[7]) + ""
                        #print(query)
                        self.cursor.execute(query)
                        self.conn.commit()

            if is_old_obj == False:
                query = ""
                if obj.img != None:
                    #print(obj.img_dir)
                    query = 'INSERT INTO ' + self.table_name + "(name,pos_x,pos_y,scale_x,scale_y,img_source,tag,id)VALUES('" + obj.name + "'," + str(
                        obj.pos_x) + "," + str(obj.pos_y) + "," + str(obj.scale_x) + "," + str(obj.scale_y) + ",'" + str(obj.img_dir) + "','" + str(obj.tag) + "'," + str(obj.id) + ");"
                    #print(query)
                else:
                    query = 'INSERT INTO ' + self.table_name + "(name,pos_x,pos_y,scale_x,scale_y,img_source,tag,id)VALUES('" + obj.name + "'," + str(
                        obj.pos_x) + "," + str(obj.pos_y) + "," + str(obj.scale_x) + "," + str(obj.scale_y) + ", 'None','" + obj.tag + "', " + str(obj.id) + ");"
                    #print(query)

                self.cursor.execute(query)

        self.conn.commit()
        self.conn.close()








