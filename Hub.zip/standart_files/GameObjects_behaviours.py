from components import *
import pygame

class Behavior:
    def __init__(self, GameObject):
        self.GameObject = GameObject

    def start(self):
        pass

    def behave(self):
        # THIS IS JUST AN EXAMPLE!
        if self.GameObject.tag == "Player":
            print("called player")
        else:
            pass

    def end(self):
        pass

    def console_log(self, what_to_log):
        self.GameObject.editor.Console.Log(what_to_log)










