import pygame

class Mouse():
    def __init__(self, editor):
        self.editor = editor
        self.is_working = False

    def work(self):
        self.is_working = True
        while self.is_working:
            k = pygame.key.get_pressed()
            if k[pygame.MOUSEBUTTONDOWN]:
                collided, Obj = self.check_if_collided()
                if collided:
                    self.on_collided(Obj)
            if k[pygame.K_q]:
                self.is_working = False

    def on_collided(self, Obj):
        print(Obj.name)

    def check_if_collided(self):
        collided = False
        o = None

        mouse_Rect = pygame.Rect(pygame.mouse.get_pos(), 32, 32)
        for obj in self.editor.all_gameObjets_lst:
            if mouse_Rect.colliderect(obj.Rect):
                collided = True
                o = obj
                break
            else:
                o = None
                collided = False

        return collided, o



