import pygame
import sqlite3
from PyQt5 import QtWidgets

class Compiler():
    def __init__(self, editor):
        self.editor = editor
        self.build_dir = None

    def read_file(self, file_name):
        s = ""
        with open(file_name, "r") as file:
            s = file.read()
            file.close()

        return s


    def create_build_files(self):
        self.editor.setVisible(False)
        self.build_dir = QtWidgets.QFileDialog.getExistingDirectory(None, "Select folder to build in!")

        editor_file_dir = self.editor.dir + "/NitroEditor.py"
        editor_file_index = self.read_file(editor_file_dir)

        gameObject_file_dir = self.editor.dir + "/GameObject.py"
        gameObject_file_index = self.read_file(gameObject_file_dir)

        saver_file_dir = self.editor.dir + "/saver.py"
        saver_file_index = self.read_file(saver_file_dir)

        components_file_dir = self.editor.dir + "/components.py"
        components_file_index = self.read_file(components_file_dir)

        behaviour_file_dir = self.editor.dir + "/GameObjects_behaviours.py"
        behaviour_file_index = self.read_file(behaviour_file_dir)

        loader_file_dir = self.editor.dir + "/loader.py"
        loader_file_index = self.read_file(loader_file_dir)

        mouse_file_dir = self.editor.dir + "/Mouse.py"
        Mouse_file_index = self.read_file(mouse_file_dir)

        compiler_file_dir = self.editor.dir + "/Compiler.py"
        compiler_file_index = self.read_file(compiler_file_dir)

        project_file_dir = self.editor.dir + "/Project.py"
        project_file_index = self.read_file(project_file_dir)

        database_file_dir = self.editor.database_file_dir

        sound_engine_file_dir = self.editor.dir + "/Sound_Engine.py"
        sound_engine_file_index = self.read_file(sound_engine_file_dir)

        try:
            #print(database_file_dir)
            conn = sqlite3.connect(database_file_dir)
            cursor = conn.cursor()
            q = f"UPDATE project_state SET build_dir = '{str(self.build_dir)}'"
            cursor.execute(q)
            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            print("Error came out!", e)

        try:
            conn = sqlite3.connect(database_file_dir)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Objects")
            objs = cursor.fetchall()
            #print(objs)
            conn.commit()
            conn.close()
        except sqlite3.Error as e:
            print("Error came out! ", e)


        with open(self.build_dir + "/Project.py", "w+") as f:
            f.write(project_file_index)
            f.close()

        with open(self.build_dir + "/NitroEditor.py", "w+") as f:
            f.write(editor_file_index)
            f.close()

        with open(self.build_dir + "/GameObject.py", "w+") as f:
            f.write(gameObject_file_index)
            f.close()

        with open(self.build_dir + "/saver.py", "w+") as f:
            f.write(saver_file_index)
            f.close()

        with open(self.build_dir + "/components.py", "w+") as f:
            f.write(components_file_index)
            f.close()

        with open(self.build_dir + "/GameObjects_behaviours.py", "w+") as f:
            f.write(behaviour_file_index)
            f.close()

        with open(self.build_dir + "/loader.py", "w+") as f:
            f.write(loader_file_index)
            f.close()

        with open(self.build_dir + "/Mouse.py", "w+") as f:
            f.write(Mouse_file_index)
            f.close()

        with open(self.build_dir + "/Compiler.py", "w+") as f:
            f.write(compiler_file_index)
            f.close()

        with open(self.build_dir + "/Sound_Engine.py", "w+") as f:
            f.write(sound_engine_file_index)
            f.close()

        try:
            conn = sqlite3.connect(self.build_dir + "/" + self.editor.project_name + ".db")
            cursor = conn.cursor()

            table1_query = "CREATE TABLE IF NOT EXISTS Objects" + '(name text, pos_x INTEGER, pos_y INTEGER,scale_x INTEGER,scale_y INTEGER ,img_source text, tag text, id INTEGER);'
            cursor.execute(table1_query)
            #print(table1_query)
            table2_query = "CREATE TABLE IF NOT EXISTS project_state(is_old_project BOOLEAN, is_compiled BOOLEAN, build_dir text)"
            cursor.execute(table2_query)
            #print(table2_query)
            q = f"INSERT INTO project_state(is_old_project, is_compiled, build_dir)VALUES('True', 'True', '{str(self.build_dir)}')"
            cursor.execute(q)
            #print(q)

            for obj in objs:
                query = f"INSERT INTO Objects (name, pos_x, pos_y, scale_x, scale_y, img_source, tag, id)VALUES('{obj[0]}', {str(obj[1])}, {str(obj[2])}, {str(obj[3])}, '{str(obj[4])}', '{str(obj[5])}', '{str(obj[6])}', {str(obj[7])})"
                #print(query)
                cursor.execute(query)
                conn.commit()

            conn.close()
        except sqlite3.Error as e:
            print("Error came out!   ", e)

        #self.editor.setVisible(True)
        #self.editor.setVisible(True)




    def compile(self):
        self.create_build_files()
        self.editor.is_compiled = False
        #self.editor.read_if_compiled()